import './Loader.css';
import React from 'react';

export const Loader = () => {
  return (
    <div className="loading-container">
      <div className="lds-facebook">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  );
};
